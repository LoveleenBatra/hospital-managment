// ---------- Utilities ----------
function goTo(page) { window.location.href = page; }

async function apiRequest(url, method = "GET", data = null) {
  const opts = { method, credentials: "same-origin", headers: {} };
  opts.credentials = 'include';
  opts.headers["X-Requested-With"] = "XMLHttpRequest";
  opts.headers["Accept"] = "application/json, text/plain, */*";

  // If data is provided, handle FormData vs JSON vs raw
  if (data) {
    if (data instanceof FormData) {
      // Browser will set correct content-type with boundary
      opts.body = data;
    } else if (typeof data === "object") {
      // If the object contains any File/Blob values, convert to FormData
      const hasFile = Object.values(data).some(v => (v instanceof File) || (v instanceof Blob));
      if (hasFile) {
        const fd = new FormData();
        for (const [k, v] of Object.entries(data)) fd.append(k, v);
        opts.body = fd;
      } else {
        opts.headers["Content-Type"] = "application/json";
        opts.body = JSON.stringify(data);
      }
    } else {
      opts.body = data;
    }
  }

  try {
    opts.credentials = "include";
    const resp = await fetch(url, opts);

    // Centralized 401 handling: show a persistent toast and emit an event; caller may handle.
    if (resp.status === 401) {
      showToast("Session expired — please login.", "error", true);
      // Dispatch an event so pages can optionally react (show login modal, etc.)
      window.dispatchEvent(new CustomEvent("app:session-expired", { detail: { httpStatus: 401 } }));
      return { status: "error", message: "unauthorized", httpStatus: 401 };
    }

    const contentType = (resp.headers.get("content-type") || "").toLowerCase();

    if (contentType.includes("application/json")) {
      const json = await resp.json();
      return { ...(json || {}), httpStatus: resp.status };
    }

    if (contentType.includes("text/html")) {
      const html = await resp.text();
      // Show HTML in a sandboxed iframe to avoid executing server scripts/styles on the page
      showHtmlOverlayAsIframe(html);
      return { status: "html", message: "html response shown in overlay", httpStatus: resp.status, raw: html };
    }

    // Fallback: try parse as text then JSON
    const text = await resp.text();
    try {
      const parsed = JSON.parse(text);
      return { ...(parsed || {}), httpStatus: resp.status };
    } catch (e) {
      showHtmlOverlayAsIframe(text);
      return { status: "unknown", message: "Non-JSON response shown", raw: text, httpStatus: resp.status };
    }

  } catch (err) {
    showToast("Network error: " + (err.message || ""), "error", true);
    return { status: "error", message: err.message || "Network error" };
  }
}

// Use an iframe with sandbox (no scripts) to render server HTML safely
function showHtmlOverlayAsIframe(html) {
  // remove old overlay if any
  let ov = document.getElementById("serverHtmlOverlay");
  if (ov) ov.remove();

  ov = document.createElement("div");
  ov.id = "serverHtmlOverlay";
  ov.style.position = "fixed";
  ov.style.inset = "0";
  ov.style.zIndex = "11500";
  ov.style.background = "rgba(0,0,0,0.6)";
  ov.style.overflow = "auto";
  ov.style.display = "flex";
  ov.style.alignItems = "center";
  ov.style.justifyContent = "center";

  // modal container
  const container = document.createElement("div");
  container.style.width = "90%";
  container.style.maxWidth = "980px";
  container.style.background = "#fff";
  container.style.borderRadius = "12px";
  container.style.padding = "10px";
  container.style.boxShadow = "0 10px 40px rgba(0,0,0,0.6)";
  container.style.display = "flex";
  container.style.flexDirection = "column";
  container.style.gap = "8px";

  const header = document.createElement("div");
  header.style.textAlign = "right";
  const closeBtn = document.createElement("button");
  closeBtn.id = "closeServerHtml";
  closeBtn.style.background = "transparent";
  closeBtn.style.border = "none";
  closeBtn.style.fontSize = "22px";
  closeBtn.style.cursor = "pointer";
  closeBtn.textContent = "✕";
  header.appendChild(closeBtn);

  const iframeWrapper = document.createElement("div");
  iframeWrapper.style.flex = "1 1 auto";
  iframeWrapper.style.minHeight = "200px";
  iframeWrapper.style.border = "1px solid #eee";
  iframeWrapper.style.borderRadius = "8px";
  iframeWrapper.style.overflow = "hidden";

  const iframe = document.createElement("iframe");
  // sandbox without allow-scripts to prevent JS execution from server HTML
  iframe.setAttribute("sandbox", "allow-forms allow-same-origin");
  iframe.style.width = "100%";
  iframe.style.height = "520px";
  iframe.style.border = "0";
  // Use srcdoc so content is shown; because iframe has no allow-scripts this avoids executing scripts.
  iframe.srcdoc = html;

  iframeWrapper.appendChild(iframe);
  container.appendChild(header);
  container.appendChild(iframeWrapper);
  ov.appendChild(container);
  document.body.appendChild(ov);

  closeBtn.onclick = () => ov.remove();

  // close on ESC: single listener bound to window for overlay lifecycle; removed when overlay removed
  function escClose(e) {
    if (e.key === "Escape") {
      ov.remove();
      window.removeEventListener("keydown", escClose);
    }
  }
  window.addEventListener("keydown", escClose);
}

function showToast(message, type = "success", persistent = false) {
  const container = getOrCreateToastContainer();
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  // animate in
  requestAnimationFrame(() => {
    toast.style.transform = "translateY(0)";
    toast.style.opacity = "1";
  });

  if (!persistent) {
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(-10px)";
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  } else {
    const close = document.createElement("button");
    close.className = "toast-close";
    close.textContent = "×";
    close.onclick = () => toast.remove();
    toast.appendChild(close);
  }
}

function getOrCreateToastContainer(){
  let container = document.getElementById("toastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    // minimal positioning so existing CSS can style it
    container.style.position = "fixed";
    container.style.right = "16px";
    container.style.top = "16px";
    container.style.zIndex = "12000";
    document.body.appendChild(container);
  }
  return container;
}

function escapeHtml(str){
  if (str === null || str === undefined) return "";
  return String(str).replace(/[&<>"']/g, s=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[s]));
}

function isValidDate(d){ return d instanceof Date && !isNaN(d); }

// Accurate age calculation (handles leap years and exact birthday)
function calcAge(dobStr){
  if(!dobStr) return "";
  const b = new Date(dobStr);
  if(!isValidDate(b)) return "";
  const today = new Date();
  let age = today.getFullYear() - b.getFullYear();
  const m = today.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < b.getDate())) age--;
  return age;
}

// DataTable helpers - only initialize if not already initialized; destroy safely
function initOrRefreshDataTable(selector) {
  if (!window.jQuery || !jQuery.fn.DataTable) return;

  const $table = jQuery(selector);
  if ($table.length === 0) return;

  // Destroy safely (but keep DOM)
  if ($.fn.DataTable.isDataTable(selector)) {
    $table.DataTable().destroy(false); // ⬅️ VERY IMPORTANT
  }

  // Initialize
  $table.DataTable({
    pageLength: 8,
    ordering: true,
    searching: true
  });
}




// ---------- Modal helpers ----------
function openPatientModal(){ const el = document.getElementById("patientModal"); if (el) el.style.display = "flex"; }
function closePatientModal(){ const el = document.getElementById("patientModal"); if (el) el.style.display = "none"; }
function openDoctorModal(){ const el = document.getElementById("doctorModal"); if (el) el.style.display = "flex"; }
function closeDoctorModal(){ const el = document.getElementById("doctorModal"); if (el) el.style.display = "none"; }
function openAppointmentModal(){ const el = document.getElementById("appointmentModal"); if (el) el.style.display = "flex"; }
function closeAppointmentModal(){ const el = document.getElementById("appointmentModal"); if (el) el.style.display = "none"; }

// ---------- PATIENTS ----------
async function fetchAndRenderPatients() {
  const res = await apiRequest("../backend/patient/get_patient.php", "GET");
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    renderPatientsTable(res.data || []);
    populatePatientSelects(res.data || []);
    setTimeout(() => {
      initOrRefreshDataTable('#patientsTable');
    }, 0);
  } else {
    showToast(res.message || "Failed to load patients", "error");
  }
}

function renderPatientsTable(patients) {
  const tbody = document.getElementById("patientList");
  if (!tbody) return;
  // build rows using DOM methods to avoid HTML injection
  tbody.innerHTML = "";
  patients.forEach(p => {
    const tr = document.createElement("tr");

    const cells = [
      p.id ?? '-',
      p.full_name ?? '-',
      (p.age ?? (p.dob ? calcAge(p.dob) : '-')),
      p.gender ?? '-',
      p.phone ?? '-',
      p.email ?? '-',
      p.address ?? '-',
      p.notes ?? '-',
      p.created_at ?? '-'
    ];

    cells.forEach(c => {
      const td = document.createElement("td");
      td.textContent = c;
      tr.appendChild(td);
    });

    const tdActions = document.createElement("td");
    const editBtn = document.createElement("button");
    editBtn.className = "small";
    editBtn.textContent = "Edit  ";
    editBtn.onclick = () => editPatient(p.id);

    const delBtn = document.createElement("button");
    delBtn.className = "small_danger";
    delBtn.textContent ="Delete  ";
    delBtn.onclick = () => deletePatient(p.id);

    tdActions.appendChild(editBtn);
    tdActions.appendChild(delBtn);
    tr.appendChild(tdActions);

    tbody.appendChild(tr);
  });
}

async function submitPatientFormSmart(e) {
  e.preventDefault();
  const form = document.getElementById("patientForm");
  if (!form) return;
  const fd = new FormData(form);
  const id = fd.get("id");
  if (id) {
    // update: convert to object first (no files expected on update); fallback to FormData if file inputs present
    const hasFileInput = Array.from(form.querySelectorAll("input[type='file']")).some(i => i.files && i.files.length);
    if (hasFileInput) {
      // send as FormData (server should accept multipart)
      const res = await apiRequest("../backend/patient/update_patient.php", "POST", fd);
      if (res.httpStatus === 401) return;
      if (res.status === "success") {
        showToast("Patient updated", "success");
        closePatientModal();
        form.reset();
        fetchAndRenderPatients();
      } else showToast(res.message || "Update failed", "error");
    } else {
      const obj = Object.fromEntries(fd.entries());
      const res = await apiRequest("../backend/patient/update_patient.php", "POST", obj);
      if (res.httpStatus === 401) return;
      if (res.status === "success") {
        showToast("Patient updated", "success");
        closePatientModal();
        form.reset();
        fetchAndRenderPatients();
      } else {
        showToast(res.message || "Update failed", "error");
      }
    }
  } else {
    // Add as FormData (ensure correct backend path lowercase)
    const res = await apiRequest("../backend/patient/add_patient.php", "POST", fd);
    if (res.httpStatus === 401) return;
    if (res.status === "success") {
      showToast("Patient added", "success");
      closePatientModal();
      form.reset();
      fetchAndRenderPatients();
    } else {
      showToast(res.message || "Add failed", "error");
    }
  }
}

async function editPatient(id) {
  const res = await apiRequest(`../backend/patient/get_single_patient.php?id=${encodeURIComponent(id)}`, "GET");
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    const f = document.getElementById("patientForm");
    if (!f) return;
    // ensure hidden id input exists and set by name
    let hid = f.querySelector("input[name='id']");
    if (!hid) {
      hid = document.createElement("input"); hid.type = "hidden"; hid.name = "id"; f.prepend(hid);
    }
    const p = res.data || {};
    // set values using name selectors to avoid ambiguity with form.id
    const setField = (name, value) => {
      const el = f.querySelector(`[name='${name}']`);
      if (el) el.value = value ?? "";
    };
    setField("id", p.id);
    setField("full_name", p.full_name ?? "");
    setField("dob", p.dob ?? "");
    setField("age", p.age ?? "");
    setField("gender", p.gender ?? "");
    setField("phone", p.phone ?? "");
    setField("email", p.email ?? "");
    setField("address", p.address ?? "");
    setField("notes", p.notes ?? "");
    openPatientModal();
  } else {
    showToast(res.message || "Failed to fetch patient", "error");
  }
}

async function deletePatient(id) {
  if (!confirm("Delete this patient?")) return;
  const res = await apiRequest("../backend/patient/delete_patient.php", "POST", { id });
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    showToast("Patient deleted", "success");
    fetchAndRenderPatients();
  } else showToast(res.message || "Delete failed", "error");
}

// populate patient selects (used by appointments)
function populatePatientSelects(patients) {
  document.querySelectorAll("select[name='patient_id']").forEach(sel => {
    const current = sel.value;
    sel.innerHTML = `<option value="">Select Patient</option>`;
    patients.forEach(p => {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = p.full_name;
      sel.appendChild(opt);
    });
    if (current) sel.value = current;
  });
}

// ---------- DOCTORS ----------
async function fetchAndRenderDoctors() {
  const res = await apiRequest("../backend/doctor/get_doctor.php", "GET");
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    renderDoctorsTable(res.data || []);
    populateDoctorSelects(res.data || []);
    initOrRefreshDataTable('#doctorTable');
  } else {
    showToast(res.message || "Failed to load doctors", "error");
  }
}

function renderDoctorsTable(rows) {
  const tbody = document.getElementById("doctorList");
  if (!tbody) return;
  tbody.innerHTML = "";
  rows.forEach(d => {
    const tr = document.createElement("tr");

    const idTd = document.createElement("td"); idTd.textContent = d.id ?? '-'; tr.appendChild(idTd);
    const nameTd = document.createElement("td"); nameTd.textContent = d.full_name ?? '-'; tr.appendChild(nameTd);
    const specTd = document.createElement("td"); specTd.textContent = d.speciality ?? '-'; tr.appendChild(specTd);
    const phoneTd = document.createElement("td"); phoneTd.textContent = d.phone ?? '-'; tr.appendChild(phoneTd);
    const emailTd = document.createElement("td"); emailTd.textContent = d.email ?? '-'; tr.appendChild(emailTd);

    const tdActions = document.createElement("td");
    const editBtn = document.createElement("button"); editBtn.className = "small"; editBtn.textContent = "Edit  "; editBtn.onclick = () => editDoctor(d.id);
    const delBtn = document.createElement("button"); delBtn.className = "small_danger"; delBtn.textContent = "Delete  "; delBtn.onclick = () => deleteDoctor(d.id);
    tdActions.appendChild(editBtn); tdActions.appendChild(delBtn);
    tr.appendChild(tdActions);

    tbody.appendChild(tr);
  });
}

async function submitDoctorFormSmart(e) {
  e.preventDefault();
  const form = document.getElementById("doctorForm");
  if (!form) return;
  const fd = new FormData(form);
  const id = fd.get("id");
  if (id) {
    const obj = Object.fromEntries(fd.entries());
    const res = await apiRequest("../backend/doctor/update_doctor.php", "POST", obj);
    if (res.httpStatus === 401) return;
    if (res.status === "success") {
      showToast("Doctor updated", "success");
      form.reset();
      closeDoctorModal();
      fetchAndRenderDoctors();
    } else showToast(res.message || "Update failed", "error");
  } else {
    const res = await apiRequest("../backend/doctor/add_doctor.php", "POST", fd);
    if (res.httpStatus === 401) return;
    if (res.status === "success") {
      showToast("Doctor added", "success");
      form.reset();
      closeDoctorModal();
      fetchAndRenderDoctors();
    } else showToast(res.message || "Add failed", "error");
  }
}

async function editDoctor(id) {
  const res = await apiRequest(`../backend/doctor/get_single_doctor.php?id=${encodeURIComponent(id)}`, "GET");
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    const f = document.getElementById("doctorForm");
    if (!f) return;
    let hid = f.querySelector("input[name='id']");
    if (!hid) {
      hid = document.createElement("input"); hid.type = "hidden"; hid.name = "id"; f.prepend(hid);
    }
    const d = res.data || {};
    const setField = (name, value) => {
      const el = f.querySelector(`[name='${name}']`);
      if (el) el.value = value ?? "";
    };
    setField("id", d.id);
    setField("full_name", d.full_name ?? "");
    setField("speciality", d.speciality ?? "");
    setField("phone", d.phone ?? "");
    setField("email", d.email ?? "");
    openDoctorModal();
  } else showToast(res.message || "Failed to fetch doctor", "error");
}

async function deleteDoctor(id) {
  if (!confirm("Delete this doctor?")) return;
  const res = await apiRequest("../backend/doctor/delete_doctor.php", "POST", { id });
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    showToast("Doctor deleted", "success");
    fetchAndRenderDoctors();
  } else showToast(res.message || "Delete failed", "error");
}

function populateDoctorSelects(doctors) {
  document.querySelectorAll("select[name='doctor_id']").forEach(sel => {
    const current = sel.value;
    sel.innerHTML = `<option value="">Select Doctor</option>`;
    doctors.forEach(d => {
      const opt = document.createElement("option");
      opt.value = d.id;
      opt.textContent = d.full_name + (d.speciality ? " — " + d.speciality : "");
      sel.appendChild(opt);
    });
    if (current) sel.value = current;
  });
}

// ---------- APPOINTMENTS ----------
async function fetchAndRenderAppointments() {
  const res = await apiRequest("../backend/appointment/get_appointment.php", "GET");
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    renderAppointmentsTable(res.data || []);
    initOrRefreshDataTable('#appointmentTable');
  } else showToast(res.message || "Failed to load appointments", "error");
}

function renderAppointmentsTable(rows) {
  const tbody = document.getElementById("appointmentList");
  if (!tbody) return;
  tbody.innerHTML = "";
  rows.forEach(a => {
    // appointment_time accepted formats: "YYYY-MM-DD HH:MM:SS" or ISO string; handle gracefully
    let date = "-", time = "-";
    if (a.appointment_time) {
      let t = a.appointment_time;
      // if space-separated datetime
      if (t.indexOf(" ") !== -1) {
        const parts = t.split(" ");
        date = parts[0] || "-";
        time = (parts[1] || "-").slice(0,5);
      } else {
        // try Date parse
        const dt = new Date(t);
        if (isValidDate(dt)) {
          date = dt.toISOString().slice(0,10);
          time = dt.toTimeString().slice(0,5);
        }
      }
    }
    const tr = document.createElement("tr");
    const cells = [
      a.id ?? '-',
      a.patient_name ?? '-',
      a.doctor_name ?? '-',
      date,
      time,
      a.notes ?? '-'
    ];
    cells.forEach(c => {
      const td = document.createElement("td");
      td.textContent = c;
      tr.appendChild(td);
    });

    const tdActions = document.createElement("td");
    const editBtn = document.createElement("button"); editBtn.className = "small"; editBtn.textContent = "Edit  "; editBtn.onclick = () => editAppointment(a.id);
    const delBtn = document.createElement("button"); delBtn.className = "small_danger"; delBtn.textContent = "Delete  "; delBtn.onclick = () => deleteAppointment(a.id);
    tdActions.appendChild(editBtn); tdActions.appendChild(delBtn);
    tr.appendChild(tdActions);

    tbody.appendChild(tr);
  });
}

async function submitAppointmentFormSmart(e) {
  e.preventDefault();
  const form = document.getElementById("appointmentForm");
  if (!form) return;
  const fd = new FormData(form);

  // combine separate date/time fields if the server expects "YYYY-MM-DD HH:MM:SS"
  if (!fd.get("appointment_time") && form.querySelector("input[name='appointment_date']") && form.querySelector("input[data-time='time']")) {
    const d = form.querySelector("input[name='appointment_date']").value;
    const t = form.querySelector("input[data-time='time']").value;
    if (d) fd.set("appointment_time", `${d} ${t || "00:00"}`);
  }

  const id = fd.get("id");
  if (id) {
    // update
    // if no file inputs, convert to object for JSON post
    const hasFileInput = Array.from(form.querySelectorAll("input[type='file']")).some(i => i.files && i.files.length);
    let res;
    if (hasFileInput) {
      res = await apiRequest("../backend/appointment/update_appointment.php", "POST", fd);
    } else {
      const obj = Object.fromEntries(fd.entries());
      res = await apiRequest("../backend/appointment/update_appointment.php", "POST", obj);
    }
    if (res.httpStatus === 401) return;
    if (res.status === "success") {
      showToast("Appointment updated", "success");
      form.reset();
      closeAppointmentModal();
      fetchAndRenderAppointments();
    } else showToast(res.message || "Update failed", "error");
  } else {
    // create
    const res = await apiRequest("../backend/appointment/add_appointment.php", "POST", fd);
    if (res.httpStatus === 401) return;
    if (res.status === "success") {
      showToast("Appointment booked", "success");
      form.reset();
      closeAppointmentModal();
      fetchAndRenderAppointments();
    } else showToast(res.message || "Booking failed", "error");
  }
}

async function editAppointment(id) {
  const res = await apiRequest(`../backend/appointment/get_single_appointment.php?id=${encodeURIComponent(id)}`, "GET");
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    const a = res.data || {};
    const f = document.getElementById("appointmentForm");
    if (!f) return;
    let hid = f.querySelector("input[name='id']");
    if (!hid) { hid = document.createElement("input"); hid.type="hidden"; hid.name = "id"; f.prepend(hid); }
    f.querySelector("[name='id']").value = a.id ?? "";

    if (f.querySelector("select[name='patient_id']")) f.querySelector("select[name='patient_id']").value = a.patient_id ?? "";
    if (f.querySelector("select[name='doctor_id']")) f.querySelector("select[name='doctor_id']").value = a.doctor_id ?? "";

    // populate datetime-local if present
    if (a.appointment_time && f.querySelector("input[name='appointment_time']") && f.querySelector("input[name='appointment_time']").type === "datetime-local") {
      const parts = String(a.appointment_time).split(" ");
      const dtVal = `${parts[0]}T${(parts[1]||"").slice(0,5)}`;
      f.querySelector("input[name='appointment_time']").value = dtVal;
    } else if (a.appointment_time && f.querySelector("input[name='appointment_date']") && f.querySelector("input[data-time='time']")) {
      const parts = String(a.appointment_time).split(" ");
      f.querySelector("input[name='appointment_date']").value = parts[0] || "";
      f.querySelector("input[data-time='time']").value = (parts[1] || "").slice(0,5);
    } else {
      // try parse as Date
      const dt = new Date(a.appointment_time);
      if (isValidDate(dt)) {
        if (f.querySelector("input[name='appointment_date']")) f.querySelector("input[name='appointment_date']").value = dt.toISOString().slice(0,10);
        if (f.querySelector("input[data-time='time']")) f.querySelector("input[data-time='time']").value = dt.toTimeString().slice(0,5);
      }
    }

    if (f.querySelector("textarea[name='notes']")) f.querySelector("textarea[name='notes']").value = a.notes ?? "";
    openAppointmentModal();
  } else showToast(res.message || "Failed to fetch appointment", "error");
}

async function deleteAppointment(id) {
  if (!confirm("Delete this appointment?")) return;
  const res = await apiRequest("../backend/appointment/delete_appointment.php", "POST", { id });
  if (res.httpStatus === 401) return;
  if (res.status === "success") {
    showToast("Appointment deleted", "success");
    fetchAndRenderAppointments();
  } else showToast(res.message || "Delete failed", "error");
}

// ---------- Init (attach listeners & load data) ----------
document.addEventListener("DOMContentLoaded", () => {
  // Attach patient form
  const patientForm = document.getElementById("patientForm");
  if (patientForm) {
    // guard against multiple attaches
    if (!patientForm.__hasSubmitAttached) {
      patientForm.addEventListener("submit", submitPatientFormSmart);
      patientForm.__hasSubmitAttached = true;
    }
    fetchAndRenderPatients();
  } else if (document.getElementById("patientList")) {
    fetchAndRenderPatients();
  }

  // Attach doctor form
  const doctorForm = document.getElementById("doctorForm");
  if (doctorForm) {
    if (!doctorForm.__hasSubmitAttached) {
      doctorForm.addEventListener("submit", submitDoctorFormSmart);
      doctorForm.__hasSubmitAttached = true;
    }
    fetchAndRenderDoctors();
  } else if (document.getElementById("doctorList")) {
    fetchAndRenderDoctors();
  }

  // Attach appointment form
  const appointmentForm = document.getElementById("appointmentForm");
  if (appointmentForm) {
    if (!appointmentForm.__hasSubmitAttached) {
      appointmentForm.addEventListener("submit", submitAppointmentFormSmart);
      appointmentForm.__hasSubmitAttached = true;
    }

    // load patients and doctors first, then appointments
    Promise.all([
      apiRequest("../backend/patient/get_patient.php", "GET"),
      apiRequest("../backend/doctor/get_doctor.php", "GET")
    ]).then(results => {
      if (results[0] && results[0].status === "success") populatePatientSelects(results[0].data || []);
      if (results[1] && results[1].status === "success") populateDoctorSelects(results[1].data || []);
      fetchAndRenderAppointments();
    });
  } else if (document.getElementById("appointmentList")) {
    Promise.all([
      apiRequest("../backend/patient/get_patient.php", "GET"),
      apiRequest("../backend/doctor/get_doctor.php", "GET")
    ]).then(results => {
      if (results[0] && results[0].status === "success") populatePatientSelects(results[0].data || []);
      if (results[1] && results[1].status === "success") populateDoctorSelects(results[1].data || []);
      fetchAndRenderAppointments();
    });
  }

  // Close modals by clicking outside modal-content — improved: only close when clicking on overlay itself
  document.querySelectorAll(".modal").forEach(modal => {
    // guard against double-attach
    if (modal.__hasOverlayListener) return;
    modal.addEventListener("click", (e) => {
      // only close if click target is the modal container (overlay), not children
      if (e.target === modal) modal.style.display = "none";
    });
    modal.__hasOverlayListener = true;
  });

  // Initialize DataTables after small delay (but avoid duplicate init)
  setTimeout(() => {
    initOrRefreshDataTable('#patientsTable');
    initOrRefreshDataTable('#doctorTable');
    initOrRefreshDataTable('#appointmentTable');
  }, 600);
});
