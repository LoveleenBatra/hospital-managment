<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$full_name = trim($input['full_name'] ?? '');
$email     = trim($input['email'] ?? null);
$phone     = trim($input['phone'] ?? null);
$dob       = trim($input['dob'] ?? null);
$age       = isset($input['age']) && $input['age'] !== '' ? (int)$input['age'] : null;
$gender    = trim($input['gender'] ?? null);
$address   = trim($input['address'] ?? null);
$notes     = trim($input['notes'] ?? null);

if ($full_name === '') {
    echo json_encode(["status"=>"error","message"=>"`full_name` is required"]);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO patients 
        (full_name, email, phone, dob, age, gender, address, notes)
        VALUES (:full_name, :email, :phone, :dob, :age, :gender, :address, :notes)");

    $stmt->execute([
        ':full_name' => $full_name,
        ':email'     => $email ?: null,
        ':phone'     => $phone ?: null,
        ':dob'       => $dob ?: null,
        ':age'       => $age,
        ':gender'    => $gender ?: null,
        ':address'   => $address ?: null,
        ':notes'     => $notes ?: null
    ]);

    $id = (int)$conn->lastInsertId();

    http_response_code(201);
    echo json_encode([
        "status"=>"success",
        "data"=>[
            "id"=>$id,
            "full_name"=>$full_name,
            "email"=>$email,
            "phone"=>$phone,
            "dob"=>$dob,
            "age"=>$age,
            "gender"=>$gender,
            "address"=>$address,
            "notes"=>$notes
        ],
        "message"=>"Patient created successfully"
    ]);
    exit;

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Server error: ".$e->getMessage()]);
    exit;
}
