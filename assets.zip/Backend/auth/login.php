<?php
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/hospital-managment',
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

require "../db.php"; // contains $conn (PDO)

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = trim($_POST["password"] ?? "");

    // Prepare PDO statement
    $stmt = $conn->prepare("SELECT id, username, role, password FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);

    // Fetch user
    $user = $stmt->fetch();

    // Validate login
    if ($user && password_verify($password, $user["password"])) {

        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["role"] = $user["role"];

        header("Location: ../../frontend/login_success.html");
        exit;

    } else {
        header("Location: ../../frontend/login_success.html?error=1");
        exit;
    }
}
?>
