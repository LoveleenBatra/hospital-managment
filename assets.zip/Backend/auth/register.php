<?php
require "../db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $confirm_password = trim($_POST["confirm_password"] ?? "");

    // REQUIRED FIELDS
    if (!$username || !$email || !$password || !$confirm_password) {
        header("Location: ../../frontend/register_success.html?error=empty");
        exit;
    }

    if ($password !== $confirm_password) {
        header("Location: ../../frontend/register_success.html?error=nomatch");
        exit;
    }

    // Password hash
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Unique username check
    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$username]);

    if ($check->fetch()) {
        header("Location: ../../frontend/register_success.html?error=duplicate");
        exit;
    }

    // Insert user
    try {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $email, $hashedPassword, "patient"]);

        header("Location: ../../frontend/register_success.html?success=1");
        exit;

    } catch (PDOException $e) {
        header("Location: ../../frontend/register_success.html?error=db");
        exit;
    }
}
?>
