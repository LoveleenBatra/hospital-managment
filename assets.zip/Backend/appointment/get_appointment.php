<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

try {
    $stmt = $conn->query("
        SELECT a.*, 
        p.full_name AS patient_name,
        d.full_name AS doctor_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        ORDER BY a.created_at DESC
    ");

    echo json_encode(["status"=>"success","data"=>$stmt->fetchAll(PDO::FETCH_ASSOC), "message"=>"Appointments fetched"]);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Server error: ".$e->getMessage()]);
    exit;
}
