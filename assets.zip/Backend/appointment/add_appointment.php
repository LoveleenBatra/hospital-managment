<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$patient_id = (int)($input['patient_id'] ?? 0);
$doctor_id = (int)($input['doctor_id'] ?? 0);
$time = trim($input['appointment_time'] ?? '');
$notes = trim($input['notes'] ?? null);

if ($patient_id <= 0 || $doctor_id <= 0 || $time === '') {
    echo json_encode(["status"=>"error","data"=>null,"message"=>"Required: patient_id, doctor_id, appointment_time"]);
    exit;
}

try {
    $stmt = $conn->prepare(
        "INSERT INTO appointments (patient_id, doctor_id, appointment_time, notes)
         VALUES (:pid, :did, :tm, :notes)"
    );

    $stmt->execute([
        ':pid'=>$patient_id,
        ':did'=>$doctor_id,
        ':tm'=>$time,
        ':notes'=>$notes ?: null
    ]);

    $id = (int)$conn->lastInsertId();
    http_response_code(201);
    echo json_encode([
        "status"=>"success",
        "data"=>[
            "id"=>$id,
            "patient_id"=>$patient_id,
            "doctor_id"=>$doctor_id,
            "appointment_time"=>$time,
            "notes"=>$notes
        ],
        "message"=>"Appointment created Successfully"
    ]);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Server error: ".$e->getMessage()]);
    exit;
}