<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    echo json_encode(["status"=>"error","data"=>null,"message"=>"`id` is required"]);
    exit;
}

try {
    $stmt = $conn->prepare("
        SELECT a.*, 
        p.full_name AS patient_name,
        d.full_name AS doctor_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        WHERE a.id = :id
        LIMIT 1
    ");
    $stmt->execute([':id'=>$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        http_response_code(404);
        echo json_encode(["status"=>"error","data"=>null,"message"=>"Appointment not found"]);
        exit;
    }

    echo json_encode(["status"=>"success","data"=>$row,"message"=>"Appointment fetched"]);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Server error: ".$e->getMessage()]);
    exit;
}
