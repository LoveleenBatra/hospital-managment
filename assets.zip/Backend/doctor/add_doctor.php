<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$full_name = trim($input['full_name'] ?? '');
$speciality = trim($input['speciality'] ?? '');
$email = trim($input['email'] ?? null);
$phone = trim($input['phone'] ?? null);

if ($full_name === '') {
    http_response_code(400);
    echo json_encode(["status"=>"error","data"=>null,"message"=>"`full_name` is required"]);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO doctors (full_name, speciality, email, phone) VALUES (:full_name, :speciality, :email, :phone)");
    $stmt->execute([
        ':full_name' => $full_name,
        ':speciality' => $speciality ?: null,
        ':email' => $email ?: null,
        ':phone' => $phone ?: null
    ]);

    $id = $conn->lastInsertId();
    http_response_code(201);
    echo json_encode([
        "status"=>"success",
        "data"=>[
            "id"=>$id,
            "full_name"=>$full_name,
            "speciality"=>$speciality,
            "email"=>$email,
            "phone"=>$phone
        ],
        "message"=>"Doctor added"
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Server error: ".$e->getMessage()]);
    exit;
}
