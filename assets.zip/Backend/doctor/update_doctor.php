<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$ct = $_SERVER['CONTENT_TYPE'] ?? '';
$in = stripos($ct,'application/json')!==false 
        ? (json_decode(file_get_contents('php://input'), true) ?? [])
        : $_POST;

$id = isset($in['id']) ? (int)$in['id'] : 0;

if ($id <= 0) {
    echo json_encode(["status"=>"error","data"=>null,"message"=>"`id` is required"]);
    exit;
}
$allowed = ['full_name','speciality','email','phone'];
$fields = [];
$params = [':id'=>$id];

foreach ($allowed as $f) {
    if (array_key_exists($f, $in)) {
        $fields[] = "$f = :$f";
        $params[":$f"] = $in[$f] !== '' ? trim($in[$f]) : null;
    }
}

if (empty($fields)) {
    http_response_code(400);
    echo json_encode(["status"=>"error","message"=>"No fields to update"]);
    exit;
}
$params[':id'] = $id;
$sql = "UPDATE doctors SET ".implode(', ', $fields)." WHERE id = :id";

try {
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    // Fetch updated record
    $q = $conn->prepare("SELECT * FROM doctors WHERE id = :id");
    $q->execute([':id'=>$id]);
    $row = $q->fetch(PDO::FETCH_ASSOC);

    echo json_encode(["status"=>"success","data"=>$row,"message"=>"Doctor updated"]);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Server error: ".$e->getMessage()]);
    exit;
}
