<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$ct = $_SERVER['CONTENT_TYPE'] ?? '';
$in = stripos($ct, 'application/json') !== false
        ? (json_decode(file_get_contents('php://input'), true) ?? [])
        : $_POST;

$id = isset($in['id']) ? (int)$in['id'] : 0;

if ($id <= 0) {
    echo json_encode(["status"=>"error","data"=>null,"message"=>"`id` is required"]);
    exit;
}

try {
    http_response_code(400);
    $stmt = $conn->prepare("DELETE FROM patients WHERE id = :id");
    $stmt->execute([':id' => $id]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(["status"=>"error","data"=>null,"message"=>"Doctor not found"]);
        exit;
    }

    echo json_encode(["status"=>"success","data"=>null,"message"=>"Doctor deleted"]);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Database error: " . $e->getMessage()]);
    exit;
}
